path_helper <- function(path, timestamp) {
		ts <- paste(strsplit(x=date(), split=' ')[[1]], sep='_', collapse='_')
		if (is.null(path)) stop("Target file or directory must be supplied.")
		if (file.exists(path)) {
			fi <- file.info(path)
			if (fi$isdir) {
				pattern <- 'pops-'
				if (timestamp) {
					pattern <- paste(pattern, ts, sep='')
				}
				target <- tempfile(pattern=paste(pattern,'-',sep=''), tmpdir=path, fileext='.rds')
			} else {
				stop("Target file already exists.")		
			}
		} else {
			target <- path
			if (timestamp) {
				target <- strsplit(x=target, split='.', fixed=TRUE)[[1]]
				if (length(target) > 1) {
					target <- paste(target[1],ts,paste(target[2:length(target)], collapse='-'),sep='-') 
				} else {
					target <- paste(target,ts,sep='-')
				}
			}
		}
		return(target)
}

population <- setRefClass(
	Class = "population",
	fields = list(
		life_cycle = "life_cycle",
		env = "list",
		sub_pops = "list"
	),
	methods = list(
		initialize = function(											### CONSTRUCTOR
			stages = NULL, parents = NULL,
			transformations = NULL,
			life_cycle = NULL, sub_pops = NULL, ...
		) {
			if (is.null(stages) && is.null(parents) && 
					is.null(life_cycle) && is.null(sub_pops)) return(.self)

			if (!is.null(stages) && !is.null(parents) && is.null(life_cycle)) {
				life_cycle <<- new('life_cycle', stages = stages, parents = parents) 
			} else {
				if (is.null(stages) && is.null(parents) && !is.null(life_cycle)) {
					life_cycle <<- life_cycle
				} else {
					msg <- "Life cycle must be specified as parents/stages or object."
					stop(msg)
				}
			}

			if (!is.null(transformations)) {
				life_cycle <<- add_transformations(.self$life_cycle, transformations)
			}

			if (is.null(sub_pops)) {
				sub_pops <<- list()
			} else {
				sub_pops <<- sub_pops
			}

			for ( stage in stage_names(.self$life_cycle) ) {
				env[[stage]] <<- new.env()
			}
			callSuper()
			return(.self)
		},
		immigrate = function(population) {						### Have another pop immigrate to this one.
			if (identical(.self$life_cycle, population$life_cycle)) {
				sub_pops <<- c(.self$sub_pops,population$sub_pops)
			} else {
				stop("Populations are not compatible.")
			}
		},
		add = function(stage, args) {

			all_args <- c(list(Class=paste(stage,'_size_distribution',sep='')), args)
			new_pop <- do.call(what=new, args = all_args, envir=.self$life_cycle@stages)
			sub_pops <<- c(.self$sub_pops, list(new_pop))
		},
		add_model = function(stage, transformation, model) {
			life_cycle <<- add_lc_node_model(life_cycle, stage, transformation, model)
		},
		transform = function(node, model, sub_pop, env) {
			## ONLY using node models, b/c the "model" string
			## is related to whether we get back a single sub_pop,
			## or a list of them to replace the original.  Then
			## we have to conditionally unlist to get the flat list
			## again.  from/to models not needed.
			f <- get_lc_node_model(.self$life_cycle, node, model)
			
			## A little awkward because there might be multiple
			## instances of a particular stage in the sub_pops list,
			## but they all use the same environment (if not, they
			## ought to be a separate stage).  Will find out what
			## sort of overhead this introduces, only relevant if the
			## "env" list gets BIG:
			if (is.function(f)) {
				return(f(sub_pop, env[[node]]))
			} else return(sub_pop)
		},
		step = function(synchronize=TRUE) {								
#     THIS WAS WRONG:
#			env <<- mcmapply(
#				FUN = function(x,y) {
#					y$sizes <- x@sizes   ### Cache sizes for use by transformations
#					return(y)
#				},
#				x = sub_pops,
#				y = env
#			)
#			In an IPM, the densities change, but the transformation is
#			calculated across all coordinates (midpoints) so that
#     doesn't matter!

			trans <- get_transformations(.self$life_cycle)
			for (i in 1:nrow(trans)) {
##				print(trans[['model']][i])
				## This next part is inefficient because some sub_pops don't
				## have a particular transformation (e.g.-juveniles don't
				## reproduce), so maybe the life_cycle object could be convinced
				## to efficiently cough up a list of calls if it becomes a
				## problem...
				sub_pops <<- mcmapply(
					FUN = .self$transform,
					node = sapply(X=sub_pops, FUN=function(x) {x@stage_name}),
					sub_pop = sub_pops,
					MoreArgs = list(
						model = trans[['model']][i],
						env = env
					),
					SIMPLIFY = FALSE
				)
				if (any(sapply(sub_pops,is.character)) )
						stop("Check sub populations, prediction failed.")
				if (any(lapply(sub_pops,length)>1)) 
					sub_pops <<- unlist(sub_pops, recursive=FALSE, use.names=FALSE)
			}
			if (synchronize) sync()
		},
		sync = function() {
			known_stages <- stage_names(.self$life_cycle)
			present_stages <- sapply(X=sub_pops, FUN=function(x) {x@stage_name})
			known_stages <- known_stages[known_stages %in% present_stages]
			o <- list()
			for ( stage in known_stages ) {
				o <- c(o,do.call(what=pool, args=sub_pops[ present_stages %in% stage ]))
			}
			sub_pops <<- o
		},
		clear = function() {
			sub_pops <<- list()
		},
		save_populations = function(path = NULL, timestamp=TRUE) {
			target <- path_helper(path, timestamp)
			saveRDS(object=sub_pops, file=target)
		},
		save = function(path = NULL, timestamp=TRUE) {
			target <- path_helper(path, timestamp)
			saveRDS(object=.self, file=target)
		},
		set_env = function(e) {
			if (is.environment(e)) {
				o <- replicate(n=length(env), expr=e)
				names(o) <- names(env)
				env <<- o
				return(env)
			} else if (is.list(e)) {
				## Single element list:
				if (!any(sapply(e,is.list))) {
					o <- replicate(n=length(env), expr=as.environment(e))
					names(o) <- names(env)
					env <<- o
					return(env)
				}
				all_elements <- !any(is.na(match(x=names(e), table=names(env))))
				if (!all_elements) { 
					stop("Some elements of 'env' not defined in argument 'e'.")
				}
				all_environments <- all(sapply(e,is.environment))
				all_lists <- all(sapply(e,is.list()))
				if (!all_environments && !all_lists) {
					stop("Not all elements of argument 'e' are environments.")
				}
				## List of environments:
				if (all_environments) {
					env <<- e
					return(env)
				}
				## List of lists:
				if (all_lists) {
					e <- lapply(e,as.environment())
					env <<- e
					return(env)
				}
			}
		},
		run = function(e = new.env(), n = 1, o = NULL) {
			## What to do with output:
			if (!is.null(o)) o_type <- file.info(o)

			## OMG R I love your type system!
			is_env <- is.environment(e)
			is_list <- is.list(e) && !is.list(e[[1]])
			if (!is_env && !is_list) {
				env_list <- all(sapply(e),is.environment)
				list_list <- all(sapply(e),is.list)
			} else { env_list <- FALSE; list_list <- FALSE }

			if (is_env || is_list) {
				set_env(e)
				for ( i in 1:n ) {
					step()
					if (!is.null(o) && o_type$isdir) save_populations(path=o)
				}
				if (!is.null(o)) save(path=o)
			}

			if (env_list || list_list) {
				for ( i in 1:n ) {
					set_env(e[[i]])
					step()
				}
			}
		}
	)
)

################################################################################
## Binary operators have to be outside of the class (as usual)
################################################################################

setMethod(
	f = "+",
	signature = signature(e1 = "population", e2 = "size_distribution"),
	definition = function(e1, e2) {
		e1 <- e1$copy(shallow=FALSE)
		e2 <- population$new(life_cycle = e1$life_cycle, sub_pops = list(e2))
		e1$immigrate(e2)
		return(e1)
	}
)

setMethod(
	f = "+",
	signature = signature(e1 = "size_distribution", e2 = "population"),
	definition = function(e1, e2) e2 + e1
)



